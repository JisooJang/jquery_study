var passport = require('passport')
    , facebookStrategy = require('passport-facebook').Strategy;

passport.use(new FacebookStrategy({
  clientID: secret_config.federation.facebook.client_id,
  clientSecret: secret_config.federation.facebook.secret_id,
  callbackURL: secret_config.federation.facebook.callback_url,
  profileFields: ['id', 'email', 'gender', 'link', 'locale', 'name',
   'timezone', 'updated_time', 'verified', 'displayName']},
   function (accessToken, refreshToken, profile, done) {
     var _profile = profile._json;

     loginByThirdparty({
       'auth_type': 'facebook',
       'auth_id': _profile.id,
       'auth_name': _profile.name,
       'auth_email': _profile.id
     }, done);
   }
}));
